Kulunvalvonnan tietokantasovellus

team4hamk

Ovilukijasovellus 1.0.

Sovellus kuvaa kulunvalvonnassa käytettävää ovilukijaa, jolle syötetään RFID-tunnus ja PIN-koodi.

Sovellus ottaa yhteyden kuti-serveriin käyttäen TCP-yhteyttä (vakioportti 6789).

Käyttöohje:

1. Syötä RFID (Enter RFID). Syötä nelinumeroinen RFID-tunnus. Numerot 0-9 kelpaa syötteeksi.
2. Syötä PIN (Enter PIN). Syötä nelinumeroinen PIN kuten kohdassa 1.
3. Ohjelma suoritus loppuu kun syötät RFID-kyselyyn numeron 0.





